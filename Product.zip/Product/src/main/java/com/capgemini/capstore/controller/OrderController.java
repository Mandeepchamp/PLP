package com.capgemini.capstore.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.CapgProduct;
import com.capgemini.capstore.beans.CustomerInventory;
import com.capgemini.capstore.beans.Purchase;
import com.capgemini.capstore.beans.Shipping;
import com.capgemini.capstore.service.OrderServiceInterface;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class OrderController {

	@Autowired
	OrderServiceInterface service;
	
	
	//Getting Product Details for Delivery
    @GetMapping(path="/product/{productId}")
	  public CapgProduct getProductById(@PathVariable int productId)
	    {  
	       return service.getProductById(productId);
	        
	    }
	
    
    //Getting Customer CapgShipping Details for Delivery
	 @GetMapping(path="/shipping/{shippingId}")
	  public Shipping getShippingStoreById(@PathVariable int shippingId)
	    {  
	        return service.getShippingById(shippingId);
	       
	    }
	 
	 //Set CustomerInventury and Update Product details
	 @PutMapping(path="/custInventury/{productId}/{customerID}/{quantity}",consumes="application/json")
	 public String setPurcase(@PathVariable int productId,@PathVariable int customerID,@PathVariable int quantity) {
		
		 CapgProduct product = service.getProductById(productId);
	
		 int newQuantity = product.getProductQuantity() - quantity;
		 /*
		  *  List<Employee> list=employeeService.getEmployeeBySalary(salary);
	       if(list.size() == 0) {
	        	//throw new EmployeeExp();
	        	throw new GlobalException();
	        }
		  */
         String productName = product.getProductName();
         int setQuantity = quantity;
         int customerId = customerID; 
         int merchantId = product.getMerchantId();
        double pri = product.getProductPrice();  
        double finalPrices = product.getFinalPrice();  
         
		 
		 // Update Product Details
		     
		     if(product != null) {  
		         if(product.isProductAvailability()==true) {
		        	 if(newQuantity>=1) {
		               product.setProductQuantity(newQuantity);  
		             service.setProduct(product);
		             System.out.println("Successfully update");
		             }else {
		            	 System.out.println("Product can't be placed");
		             }
		         }else {
		        	 System.out.println("Product not available");
		         }
		     }/*else {
		    	 System.out.println("Product Not Found");
		     }*/
		     
		     int prodId = productId;
		      //Set Purchase table 
		     Purchase purchase = new Purchase();
		            purchase.setProductID(prodId);
		        
		            purchase.setProductName(productName);
		         
		            purchase.setQuantity(setQuantity);
		           
		            purchase.setCustomerID(customerId);
		            
		            purchase.setMerchantID(merchantId);
		            //final price update
		            purchase.setProductPrice(finalPrices);
		     service.setPurchase(purchase);
		     
		     //Set Customer Inventory Table
		     CustomerInventory custInventory = new CustomerInventory();
		    
		     custInventory.setCustomerID(customerId);
		     custInventory.setProductID(prodId);
		     custInventory.setProductName(productName);
		     custInventory.setQuantity(setQuantity);
		     service.setCustomerInvenetory(custInventory);
		   
		     return "Updating customerInventory and Purchase table";
		 
	 }
}
