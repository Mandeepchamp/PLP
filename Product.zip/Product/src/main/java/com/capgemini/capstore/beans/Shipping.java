package com.capgemini.capstore.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import org.springframework.stereotype.Component;
@Component
@Entity(name="CapgShipping")
public class Shipping {
	
	 @Id
	 @SequenceGenerator(name="seq" , sequenceName = "product_seq")
	 @GeneratedValue(generator = "seq")
	 int  shippingID;
	 String customerName;
	 String customerAddress;
	 Long customerMobile;
	 String customerEmail;
	 String shippingStatus;
	 Long cebitCard;
	 Long creditCard;
	public int getShippingID() {
		return shippingID;
	}
	public void setShippingID(int shippingID) {
		this.shippingID = shippingID;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public Long getCustomerMobile() {
		return customerMobile;
	}
	public void setCustomerMobile(Long customerMobile) {
		this.customerMobile = customerMobile;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public String getShippingStatus() {
		return shippingStatus;
	}
	public void setShippingStatus(String shippingStatus) {
		this.shippingStatus = shippingStatus;
	}
	public Long getCebitCard() {
		return cebitCard;
	}
	public void setCebitCard(Long cebitCard) {
		this.cebitCard = cebitCard;
	}
	public Long getCreditCard() {
		return creditCard;
	}
	public void setCreditCard(Long creditCard) {
		this.creditCard = creditCard;
	}
	@Override
	public String toString() {
		return "Shipping [shippingID=" + shippingID + ", customerName=" + customerName + ", customerAddress="
				+ customerAddress + ", customerMobile=" + customerMobile + ", customerEmail=" + customerEmail
				+ ", shippingStatus=" + shippingStatus + ", cebitCard=" + cebitCard + ", creditCard=" + creditCard
				+ "]";
	}
	 
	 
}
