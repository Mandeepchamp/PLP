package com.capgemini.capstore.dao;



import com.capgemini.capstore.beans.CapgProduct;
import com.capgemini.capstore.beans.CustomerInventory;
import com.capgemini.capstore.beans.Purchase;
import com.capgemini.capstore.beans.Shipping;

public interface OrderDaoInterface {

	CapgProduct getProductById(int pId);

	Shipping getShippingById(int shippingId);

	void setPurchase(Purchase purchase);

	void setProduct(CapgProduct product);

	void setCustomerInvenetory(CustomerInventory custInventory);

	

}
