package com.capgemini.capstore.service;



import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.CapgProduct;
import com.capgemini.capstore.beans.CustomerInventory;
import com.capgemini.capstore.beans.Purchase;
import com.capgemini.capstore.beans.Shipping;

@Service
public interface OrderServiceInterface {

	CapgProduct getProductById(int pId);

	Shipping getShippingById(int shippingId);

	void setPurchase(Purchase purchase);

	void setProduct(CapgProduct product);

	void setCustomerInvenetory(CustomerInventory custInventory);

}
