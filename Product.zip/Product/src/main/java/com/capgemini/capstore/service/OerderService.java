package com.capgemini.capstore.service;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.CapgProduct;
import com.capgemini.capstore.beans.CustomerInventory;
import com.capgemini.capstore.beans.Purchase;
import com.capgemini.capstore.beans.Shipping;
import com.capgemini.capstore.dao.OrderDaoInterface;
import com.capgemini.capstore.dao.OrderRepositoryInterface;


@Service
public class OerderService implements OrderServiceInterface{
	@Autowired
	OrderDaoInterface dao;
	
	
	@Override
	public CapgProduct getProductById(int pId) {
		// TODO Auto-generated method stub
		return dao.getProductById(pId);
	}

	@Override
	public Shipping getShippingById(int shippingId) {
		// TODO Auto-generated method stub
		return dao.getShippingById(shippingId);
	}

	@Override
	public void setPurchase(Purchase purchase) {
		dao.setPurchase(purchase);
		
	}

	@Override
	public void setProduct(CapgProduct product) {
		
		dao.setProduct(product);
	}

	@Override
	public void setCustomerInvenetory(CustomerInventory custInventory) {
	    dao.setCustomerInvenetory(custInventory);
		
	}

	
	
}
