package com.capgemini.capstore.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.CapgProduct;
import com.capgemini.capstore.beans.CustomerInventory;
import com.capgemini.capstore.beans.Purchase;
import com.capgemini.capstore.beans.Shipping;



@Repository
public class OrderRepository implements OrderDaoInterface{

	
	@Autowired
	OrderRepositoryInterface repo;
	@Autowired
	ShippingRepositoryInterface  repo1;
	@Autowired
	CustomerInventoryRepositoryInterface repo2;
	@Autowired
	PurchaseRepositoryInterface repo3;
	
	@Override
	public CapgProduct getProductById(int pId) {
		return repo.findById(pId).orElse(null);
	}
	

	@Override
	public Shipping getShippingById(int shippingId) {
		// TODO Auto-generated method stub
		return  repo1.findById(shippingId).orElse(null);
	}

	@Override
	public void setPurchase(Purchase purchase) {
		
		repo3.save(purchase);
	}

	@Override
	public void setProduct(CapgProduct product) {
		repo.save(product);
	}

	@Override
	public void setCustomerInvenetory(CustomerInventory custInventory) {
		
		repo2.save(custInventory);
	}

	

	
	 
	
}
