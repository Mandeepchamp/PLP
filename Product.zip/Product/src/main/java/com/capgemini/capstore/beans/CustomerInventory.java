package com.capgemini.capstore.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;


@Component
@Entity(name="CAPGINVENTORY")
public class CustomerInventory {
	@Id
	@SequenceGenerator(name="seq" , sequenceName = "product_sequence")
	@GeneratedValue(generator = "seq")
	int inventoryId;
	int customerID;
	int productID;
	String productName;
	int quantity;
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public int getProductID() {
		return productID;
	}
	public void setProductID(int productID) {
		this.productID = productID;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public int getInventoryId() {
		return inventoryId;
	}
	public void setInventoryId(int inventoryId) {
		this.inventoryId = inventoryId;
	}
	@Override
	public String toString() {
		return "CustomerInventory [customerID=" + customerID + ", productID=" + productID + ", productName="
				+ productName + ", quantity=" + quantity + "]";
	}
	
	
}
