package com.capgi.exception;

public class OrderException extends Exception{

}
