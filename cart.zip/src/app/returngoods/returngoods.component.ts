import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-returngoods',
  templateUrl: './returngoods.component.html',
  styleUrls: ['./returngoods.component.css']
})
export class ReturngoodsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
