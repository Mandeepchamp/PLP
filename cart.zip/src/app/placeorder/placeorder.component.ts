import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CapstoreService } from '../capstore.service';
import { Product } from '../Product';
@Component({
  selector: 'app-placeorder',
  templateUrl: './placeorder.component.html',
  styleUrls: ['./placeorder.component.css']
})
export class PlaceorderComponent implements OnInit {
  router: Router;
  constructor(private service:CapstoreService, router: Router) { 
    this.router = router;
  }

  productId: number;
  customerId: number;
  productQuantity:number;
  product: Product=new Product();

  ngOnInit() {
    this.productId=this.service.getProductId();
    this.customerId=this.service.getCustomerId();
    this.productQuantity=this.service.getProductQuantity();
   
    this.setProduct();
    this.getProduct();
  }

  getProduct() {
    alert(this.productId);
    return this.service.getProduct(this.productId).subscribe(data=>this.product=data);

  }

  setProduct() {
    alert(this.customerId);

    return this.service.setPurcase(this.productId,this.customerId,this.productQuantity).subscribe(data => console.log(data), error => console.log(error));
  }
}




