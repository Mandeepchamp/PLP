import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CartComponent } from './cart/cart.component';
import { PlaceorderComponent } from './placeorder/placeorder.component';
import { ReturngoodsComponent } from './returngoods/returngoods.component';
import { ShippingorderComponent } from './shippingorder/shippingorder.component';
const routes: Routes = [

  {path:'cart',component:CartComponent},
  {path:'placeorder',component:PlaceorderComponent},
  {path:'returnproduct',component:ReturngoodsComponent},
  {path:'shippingproduct',component:ShippingorderComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
