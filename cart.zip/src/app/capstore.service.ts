import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Cart } from './Cart';
import { HttpClient } from '@angular/common/http';
import { Product } from './Product';
import { Customer } from './Customer';
import { CartProduct } from './CartProduct';

@Injectable({
  providedIn: 'root'
})
export class CapstoreService {

  // http:HttpClient;
  cartproduct: CartProduct[]=[];
  customer:Customer[]=[];
  product:Product[]=[];
  

  productId: number;
  customerId: number;
  productQuantity:number;
  private baseUrl = 'http://localhost:9091';
  constructor(private http: HttpClient) { }

 
  
  

  getcart():CartProduct[]{
    return this.cartproduct;
  }

  setData(productId, customerId,productQuantity) {
    this.productId=productId;
    this.customerId=customerId;
    this.productQuantity=productQuantity;
  }

  getProductId() {
    return this.productId;
  }

  getCustomerId() {
    return this.customerId;
  }
  getProductQuantity(){
    return this.productQuantity;
  }
  getProduct(productId):Observable<any> {
    return this.http.get("http://localhost:9091/product/"+productId);
  }

  setPurcase(productId,customerID,productQuantity): Observable<any>{
    alert(this.customerId)
    return this.http.put(`${this.baseUrl}/custInventury/${productId}/${customerID}/${productQuantity}`,"");
  }
 

}

