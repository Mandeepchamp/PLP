export class Product {
	private productId: number;
	private productAvailability: boolean;
	private productBrand: string;
	private productCategory: string;
	private productDiscount: number;
	private productFeedback: string;
	private productImage: string;
	private productName: string;
	private productPrice: number;
	private productQuantity: number;
	private productRating: number;
	private productType: string;
	private merchantId: number;
	private finalPrice: number;
}



