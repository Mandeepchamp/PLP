import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shippingorder',
  templateUrl: './shippingorder.component.html',
  styleUrls: ['./shippingorder.component.css']
})
export class ShippingorderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
