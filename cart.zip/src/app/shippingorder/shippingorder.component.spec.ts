import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShippingorderComponent } from './shippingorder.component';

describe('ShippingorderComponent', () => {
  let component: ShippingorderComponent;
  let fixture: ComponentFixture<ShippingorderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShippingorderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShippingorderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
