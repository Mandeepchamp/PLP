import { Component, OnInit } from '@angular/core';
import { Cart } from '../Cart';
import { Router } from '@angular/router';
import { CapstoreService } from '../capstore.service';
import { CartProduct } from '../CartProduct';
import { Product } from '../Product';
import { Customer } from '../Customer';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  router: Router;
 
  constructor(private service:CapstoreService, router: Router) {
    this.router = router;
   }
cart:Cart;
  cart1:Cart[];
  cartProduct:CartProduct[];
  product: Product[];
  customer:Customer[];
  quantity:number;
  ngOnInit() {
   
  }


  showDetails(data) {
    this.quantity = data.productQuantity;
    this.service.setData(data.productId,data.customerId,this.quantity);
    this.router.navigate(['/placeorder']);
  }





}
