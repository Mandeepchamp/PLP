import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { HttpClientModule } from '@angular/common/http';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CartComponent } from './cart/cart.component';
import { PlaceorderComponent } from './placeorder/placeorder.component';
import { ReturngoodsComponent } from './returngoods/returngoods.component';
import { ShippingorderComponent } from './shippingorder/shippingorder.component';

@NgModule({
  declarations: [
    AppComponent,
    CartComponent,
    PlaceorderComponent,
    ReturngoodsComponent,
    ReturngoodsComponent,
    ShippingorderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
